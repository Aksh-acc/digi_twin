"""
splits.py
=========
Loads the unified per-source jsonl and produces reproducible train/test splits.

Two ideas matter here:

1. GROUPED splitting. For human data we split by `participant_id` so one
   person's answers never straddle train and test. For agent data we split by
   the (agent, category) group so the test set always contains held-out
   product configurations, not just held-out rows an agent already saw.
   This makes "accuracy" mean generalisation, not memorisation.

2. A FIXED test set per source. The transfer matrix needs the SAME test set
   regardless of what we trained on, otherwise the four cells aren't
   comparable. So we compute, once, a train/test split for each source, and
   every experiment reuses those exact indices.
"""

import json

from sklearn.model_selection import GroupShuffleSplit


def load_source(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            rows.append(json.loads(line))
    return rows


def grouped_split(rows, test_size=0.2, seed=42, group_key="group"):
    """Return (train_rows, test_rows) split by group so no group leaks."""
    groups = [r[group_key] for r in rows]
    gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
    train_idx, test_idx = next(gss.split(rows, groups=groups))
    train = [rows[i] for i in train_idx]
    test = [rows[i] for i in test_idx]
    return train, test


def build_splits(cfg):
    """
    Build the fixed train/test splits for both sources.

    Returns a dict:
        { "agent": {"train": [...], "test": [...]},
          "human": {"train": [...], "test": [...]} }
    """
    unified = cfg["data"]["unified_dir"]
    test_size = cfg["data"]["test_size"]
    seed = cfg["data"]["seed"]

    agent_rows = load_source(f"{unified}/agent.jsonl")
    human_rows = load_source(f"{unified}/human.jsonl")

    # Agents: group by "agent + category" so held-out = unseen product configs.
    for r in agent_rows:
        r["_split_group"] = f"{r['group']}||{r['category']}"
    # Humans: group by participant.
    for r in human_rows:
        r["_split_group"] = r["group"]

    a_train, a_test = grouped_split(agent_rows, test_size, seed, "_split_group")
    h_train, h_test = grouped_split(human_rows, test_size, seed, "_split_group")

    return {
        "agent": {"train": a_train, "test": a_test},
        "human": {"train": h_train, "test": h_test},
    }
