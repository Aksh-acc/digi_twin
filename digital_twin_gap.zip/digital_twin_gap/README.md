# Digital-Twin Gap Study

Measuring **how well a "digital twin" of shopping decisions transfers between LLM
agents and real humans** — across several model architectures — for a research
paper.

You already built a two-model digital twin (a cVAE numeric twin + a Qwen2.5-3B
LoRA LLM twin) and ran the agent-vs-human comparison on it. This repo is the
**complementary, architecture-comparison track**: it takes the *same* decision
task (given a shopping prompt with four options, predict which option is chosen)
and runs it through **three additional, lighter architectures**, each evaluated
on the full agent↔human **transfer matrix**, so the *gap* between agents and
humans is measured directly and comparably.

Everything runs on **Google Colab, Kaggle, or locally** with no code changes.

---

## 1. The research question

> If you build a digital twin from **LLM-agent** shopping decisions, how well
> does it stand in for **real human** consumers — and vice-versa?

We answer it with a 2×2 **transfer matrix** per architecture:

|              | test = agent | test = human |
|--------------|:------------:|:------------:|
| train = agent | A→A (matched) | A→H (transfer) |
| train = human | H→A (transfer) | H→H (matched) |

- **Diagonal** = matched twin (trained and tested on the same population).
- **Off-diagonal** = transferred twin (trained on one, tested on the other).
- **Gap** = matched accuracy − transferred accuracy. A large gap means a twin
  built from the wrong population is a poor stand-in.

---

## 2. Data

Two sources, reduced to one shared schema so the same models consume both:

```
{ "prompt": "<full shopping prompt: mandate + 4 options>",
  "label" : "A" | "B" | "C" | "D" | "NONE",     # the chosen option
  "source": "agent" | "human",
  "group" : "<agent name>" | "<participant_id>", # for leak-free splits
  "category": "AIR" | "COF" | "EAR" | "SNK" }
```

**Agentic data** — LLM "shopping agents" answering the *same* product-choice
prompts. Six agents are included:

| Agent | Rows |
|---|---|
| Claude Opus 4.6 | 384 |
| Claude Sonnet 4.6 | 384 |
| Claude Opus 4.8 | 384 |
| ChatGPT O3 | 384 |
| ChatGPT GPT-5.5 | 384 |
| Grok 4.2 | 334¹ |
| **Total** | **2,254** |

¹ Grok's first batch (NO1–50) ships without a `full_chat_prompt` column, so
those 50 rows are skipped (a model needs the prompt as input). Everything else
is complete. All agents answered the **same 72 product configurations**, which
is what makes cross-agent and agent-vs-human comparison valid.

**Human data** — real survey respondents' actual choices on the real product
options they were shown (the pre-built `llm_train_human.jsonl` /
`llm_val_human.jsonl` from the original project). **6,016** decisions from 571
participants.

Both sources are split **grouped** so nothing leaks between train and test:
humans are split by `participant_id`; agents are split by `(agent, category)` so
the test set is always **held-out product configurations**, not rows the model
already saw. The split is fixed and reused across all four cells so the matrix is
comparable.

---

## 3. The architectures

All three predict the same label (chosen option A/B/C/D) from the same prompt
text, and expose the same `fit()` / `predict()` interface, so `run_all.py`
treats them interchangeably.

### (1) `tfidf_logreg` — TF-IDF + Logistic Regression
`src/model_tfidf.py`. Prompt → sparse bag-of-n-grams (uni+bigrams, 20k features,
sublinear TF) → multinomial logistic regression, `class_weight="balanced"`.
Pure CPU, trains in ~2 seconds. This is the **honest floor**: if a heavy
transformer can't beat it, that's a finding.

### (2) `embed_mlp` — frozen sentence embeddings + MLP head
`src/model_embed_mlp.py`. Prompt → **frozen** `all-MiniLM-L6-v2` sentence encoder
(384-dim) → 2-layer MLP classifier (256→128→4) with dropout and class-weighted
cross-entropy. The expensive encoder never trains — only the small head does. A
clean **representation-learning probe**: "how linearly separable are agent vs
human choices in a good semantic space?" Runs on CPU, faster on GPU.

### (3) `distilbert` — fine-tuned transformer classifier
`src/model_distilbert.py`. `distilbert-base-uncased` fine-tuned end-to-end as a
4-way sequence classifier via Hugging Face `Trainer` (max_length 512, 3 epochs,
lr 2e-5, gradient accumulation for small-VRAM safety, fp16 on GPU). The
**strongest** twin here and the one most likely to close — or provably fail to
close — the gap. 66M params: fits free-tier Colab/Kaggle GPUs; falls back to
(slow) CPU so the pipeline never hard-fails.

> These are deliberately **different from and lighter than** your cVAE +
> Qwen-3B twins. The point of this track is an architecture *comparison* on the
> transfer gap, not another single heavyweight model. All three are cheap enough
> to run the whole 4-cell matrix in one Colab session.

---

## 4. Quick start

### On Colab / Kaggle (recommended)
1. Zip this whole folder → `digital_twin_gap.zip`.
2. Open `notebooks/run_on_colab_or_kaggle.ipynb` in Colab (or import to Kaggle).
3. Set the runtime to **GPU** (for `distilbert`): *Runtime → Change runtime type → GPU*.
4. Run cells top to bottom. The notebook handles upload / Google Drive / Kaggle
   dataset, installs deps, builds data, runs experiments, and shows the figures.

### Locally / on a server
```bash
pip install -r requirements.txt

# 1. Build the unified dataset from data/raw/
python -m src.data_prep --config configs/config.yaml

# 2. Run experiments (all three, or name a subset)
python -m src.run_all --config configs/config.yaml
python -m src.run_all --config configs/config.yaml --models tfidf_logreg   # quick

# 3. Make figures + report
python -m src.analyze --config configs/config.yaml
```
Or just: `bash run_all.sh` (all) / `bash run_all.sh tfidf_logreg` (one).

---

## 5. Where your data goes

`configs/config.yaml` expects (relative to the project root):

```
data/raw/
├── Agentic response/          # the 6-agent .xlsx tree
│   ├── Claude/{Opus 4.6, Sonnet 4.6, Opus 4.8}/*.xlsx
│   ├── Chatgpt/{O3, GPT 5.5}/*.xlsx
│   └── Grok 4.2/Grok 4.2/*.xlsx
└── human/
    ├── llm_train_human.jsonl
    └── llm_val_human.jsonl
```

The data that shipped with this project is already staged there. If yours lives
elsewhere, edit only the two paths under `data:` in `configs/config.yaml`
(`agentic_root` and `human_files`).

---

## 6. Outputs

Written to `results/`:

| File | What |
|---|---|
| `all_results.json` | Every cell, full metrics, per-agent breakdown |
| `summary_matrix.csv` | Flat table: one row per architecture × transfer cell |
| `gap_report.csv` | Headline gap numbers per architecture |
| `report.txt` | Plain-language summary |
| `fig_transfer_matrix.png` | 2×2 accuracy heatmap per architecture |
| `fig_gap_bars.png` | Matched vs transferred accuracy, side by side |
| `fig_per_agent.png` | Per-agent accuracy (which agents the twin models best) |

---

## 7. Example results (TF-IDF, verified run)

Grouped, leak-free splits; 4-way random baseline = 0.25.

| | test: agent | test: human |
|---|:---:|:---:|
| **train: agent** | **0.665** | 0.383 |
| **train: human** | 0.427 | **0.433** |

Read off the gaps:
- **Agents are far more predictable than humans** — an agent-matched twin hits
  0.665, a human-matched twin only 0.433 (barely above chance). LLM agents make
  consistent, rule-like choices; real people are noisier.
- **Transfer hurts** — an agent-trained twin drops to 0.383 on humans; a
  human-trained twin drops to 0.427 on agents (well below the 0.665 an
  agent-trained twin reaches).
- **Implication for the paper:** an "agentic digital twin" *overstates* how well
  it would model human consumers. This is exactly the gap this repo quantifies —
  and running `embed_mlp` and `distilbert` shows whether a stronger architecture
  narrows it or whether the gap is intrinsic to the human/agent difference.

(These are the TF-IDF numbers, which run anywhere in seconds. The two neural
architectures download their base models from Hugging Face on first run — do
that on Colab/Kaggle, where the numbers for all three fill the same tables.)

---

## 8. Project layout

```
digital_twin_gap/
├── README.md
├── requirements.txt
├── run_all.sh                     # one-shot: prep -> experiments -> analysis
├── configs/
│   └── config.yaml                # paths + all hyperparameters
├── notebooks/
│   └── run_on_colab_or_kaggle.ipynb
├── src/
│   ├── data_prep.py               # agent .xlsx + human .jsonl -> unified schema
│   ├── splits.py                  # fixed, grouped, leak-free train/test splits
│   ├── model_tfidf.py             # architecture 1
│   ├── model_embed_mlp.py         # architecture 2
│   ├── model_distilbert.py        # architecture 3
│   ├── metrics.py                 # accuracy, macro-F1, per-agent, gap
│   ├── run_all.py                 # runs the full transfer matrix
│   └── analyze.py                 # figures + text report
├── data/
│   ├── raw/                       # your input data (agent xlsx + human jsonl)
│   └── unified/                   # generated by data_prep.py
└── results/                       # generated outputs
```

---

## 9. Adding a fourth architecture

Drop a `src/model_yours.py` exposing `fit(train_rows, cfg)` and
`predict(model, test_rows)`, add its key to `MODEL_REGISTRY` in `run_all.py` and
a block under `models:` in `config.yaml`, then
`python -m src.run_all --models yours`. The transfer matrix, metrics, gap
computation, and plots all pick it up automatically.
